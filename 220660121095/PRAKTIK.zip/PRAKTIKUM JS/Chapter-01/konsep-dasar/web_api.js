/*alert();
console.log();
setTimeout();
setInterval();
localStorage;
sessionStorage;
*/

// event listener
// const btn = document.getElementById("btn");
// btn.addEventListener("click", function () {
//   alert("Belajar JavaScript");
// });

window.setTimeout(() => {
    console.log("Timer finished");
  }, 1000);
  
  window.alert("Belajar JavaScript");
  
  // Atau
  setTimeout(() => {
    console.log("Timer finished");
  }, 1000);
  
  alert("Belajar JavaScript");