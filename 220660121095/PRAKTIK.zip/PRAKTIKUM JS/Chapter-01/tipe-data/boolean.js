var a = true;
typeof a; //boolean

//sama seperti Number, nilai boolean yang dibungkus //oleh tanda petik berubah menjadi string
var b = "true";
typeof b; //string