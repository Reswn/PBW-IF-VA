//contoh implementasi objek

//notasi objek
var person = {
    nama: "John Doe",
    umur: 25,
    alamat: "Jl. Raya No. 1",
  };
  
  //associative-array
  var orang = {};
  orang["nama"] = "Jane Doe";
  orang["umur"] = 30;
  orang["alamat"] = "Jl. Raya No. 2";
  
  console.log(person);
  console.log(orang);