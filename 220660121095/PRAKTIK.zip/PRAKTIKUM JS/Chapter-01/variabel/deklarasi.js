//semua dalam satu baris
var brand = "honda",
  type = "mpv",
  numberOfWheels = 4,
  price;

//baris terpisah (lebih baik daripada satu baris)
var brand = "honda",
  type = "mpv",
  numberOfWheels = 4,
  price;