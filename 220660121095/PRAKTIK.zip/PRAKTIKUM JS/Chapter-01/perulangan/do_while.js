var a = [];
var i = 0;

do {
  a.push(i);
  i++;
} while (i < 4);

console.log(a); //[0,1,2,3]
 6 changes: 6 additions & 0 deletions6 