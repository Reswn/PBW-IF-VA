function check(c) {
    console.log(c > 0 ? "ok" : "not ok");
  }